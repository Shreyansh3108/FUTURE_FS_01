export default function Footer() {
  return (
    <footer className="text-center py-6 text-sm text-gray-500">
      © 2025 John Doe. Built with React.
    </footer>
  );
}